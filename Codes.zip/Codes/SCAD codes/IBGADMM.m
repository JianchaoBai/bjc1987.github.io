function [k,x,y,tim,f0,history] = IBGADMM(A,b,para)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This codes comes from the paper [Xu, Chao, An inertial Bregman generalized alternating direction
% method of multipliers for nonconvex optimization, Journal of Applied Mathematics and Computing
% https://doi.org/10.1007/s12190-021-01590-1]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
%%%%%%%%%%% initial parameters%%%%%%%%%%% 
c     = para.c;
kappa = para.kappa;
beta  = 1.03;
mu1    = 7.5;
alpha = 1.26;
rho = .09; theta = .99;
%%%%%%%%%%initial iteration%%%%%%%%%%%%%%
[m, n] = size(A);
y = zeros(m,1); y_hat = y; y_0 = y;  %����m*1��0����
x = zeros(n,1); x_hat =x;  x_0 = x;
lambda = y;

const_b = beta*para.Ab;
f0 =  sum((y).^2)/2 + SCA(x,kappa,c);

for k = 1:para.MAX_ITER
    tic;
    %--------- x-update------------------------------------------
    diff_x = x_hat - x_0;
    Temp_xk = (const_b + beta*(A'*y-para.ATA*x_hat) + theta*diff_x + A'*lambda + mu1*x_hat)/mu1;
    x = scad_prox(Temp_xk,c,1/mu1,kappa);
    
    diff_xnew = x - x_hat;
    % -----------y-update-----------------------------------------
    mu2 = k;
    y_ma = rho*(y_hat-y_0);
    
    y = (beta*alpha*(A*x-b) - beta*(1-alpha)*y_hat + mu2*y_hat + y_ma - lambda )/(1+beta+mu2);
    diff_y = y-y_hat;
    
    diff_equ = A*x - y - b;
    % ----------------lambda-update-------------------------------
    lambda = lambda - beta*(alpha*diff_equ - (1-alpha)*diff_y);
     
   
    % -----diagnostics, reporting, termination checks-------------
    tt = toc;
    if k==1
        history.cpu(k) = tt;
    else
       history.cpu(k) = history.cpu(k-1) +tt; 
    end
    history.obj(k) = sum((y).^2)/2 + SCA(x,kappa,c);
    equ_norm =  norm(diff_equ);
    KKT_1 = norm(y +lambda);
    history.RK(k) = norm(diff_xnew) + norm(diff_y) + equ_norm;
    history.opt(k)= max(equ_norm, KKT_1); % KKT residual
    tim = history.cpu(k);
%     fprintf('It_out:%3d\t Rk:%8.4e\t Fk:%8.4e\t Optk:%8.4e\t Equ:%5.4e\t KKT1:%8.4e\n',...
%              k,history.RK(k),history.obj(k),history.opt(k),equ_norm,KKT_1);  
    if tim>= para.Time_Budget %history.opt(k)<1e-6  
       break;
    end
    x_0   = x_hat;
    y_0   = y_hat;
    x_hat = x;
    y_hat = y;
end
fprintf('It_out:%3d\t Fk: %o\t Optk: %8.4e\t Rk:%8.4e\n',...
         k,history.obj(k), history.opt(k),history.RK(k))
fprintf('time:%4.4f\n', tim)
end

 

