function y = scad_prox(x, c, v, kappa)
len=length(x);
y=ones(len,1);
for i=1:1:len
      ax = abs(x);
      ax = ax(i);
      if ax <= (1+v)*kappa
               y(i) = sign(x(i))*max(0, ax - kappa*v);
       else if  ax > (1+v)*kappa && ax <= c*kappa
               y(i) = ((c-1)*x(i)-sign(x(i))*c*kappa*v)/(c-1-v);
              else
                 y(i) = x(i);
           end
       end
end
end

function temp=sign(xi)
if xi>0
    temp=1;
else if xi<0
        temp=-1;
    else
        temp=0;
    end
end
end