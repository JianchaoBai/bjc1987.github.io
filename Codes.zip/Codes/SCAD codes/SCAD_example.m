%%%%%%%%%%%%%%%%%%%%%% tests %%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc
clear all
randn('seed', 0); 
% %problem dimension 
   m = 500;  n = 3000;  para.Time_Budget= 20;
% %  m = 1000; n = 6000;  para.Time_Budget= 50;
%   m = 2000; n = 9000;  para.Time_Budget= 140;
%   m = 3000; n = 12000; para.Time_Budget=180;
 
 
p = 100/n;
x0 = sprandn(n,1,p);
A  = randn(m,n);
A  = A*spdiags(1./sqrt(sum(A.^2))',0,n,n);
b  = A*x0 + sqrt(0.001)*randn(m,1);

%% =================================
para.MAX_ITER=10e8;
para.kappa = 0.1;
para.c = 3.7;
para.ATA = A'*A;
para.AAT = A*A';
para.Ab  = A'*b;
para.v= norm(para.ATA);
% fprintf(" Lip: %e \n", para.v);
% 
%% Comparative experiments by state-of-the-art algorithms
% 
    [k,x,y,tim,~,history] =  I_ADMM_New(A,b,para,1.2); %eta=1.2 
    [k1,x1,y1,tim1,f0,history1] = IBGADMM(A,b,para);
    [k2,x2,y2,tim2,~,history2] = NL_ADMM(A,b,para);
    [k3,x3,y3,tim3,~,history3] = PADMM(A,b,para);   
    [k4,x4,y4,tim4,~,history4] = BPADMM(A,b,para);
    [k5,x5,y5,tim5,~,history5] = SADMM(A,b,para); 

