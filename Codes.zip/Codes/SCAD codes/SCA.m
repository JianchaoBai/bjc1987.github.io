%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function tem=SCA(x,kappa,c)
tem = 0;
for i=1:1:length(x)
    xi = abs(x(i));
    if xi<=kappa
        gi = kappa*xi;
    elseif   xi>kappa  &&  xi<=c*kappa
        gi = 0.5/(c-1)*(-xi^2+2*c*kappa*xi-kappa^2);
    else
        gi =0.5*(c+1)*kappa^2;
    end
    tem = tem + gi;
end
end