% %    
    history1.cpu(end)=para.Time_Budget;
    history2.cpu(end)=para.Time_Budget;
    history3.cpu(end)=para.Time_Budget;
    history4.cpu(end)=para.Time_Budget;
    history5.cpu(end)=para.Time_Budget;
    history.cpu(end)=para.Time_Budget;

set(groot,'defaultLineLineWidth',1.2) %�������Դ�ϸ
fmin = min([history1.obj(end),history2.obj(end),history3.obj(end),...
            history4.obj(end),history5.obj(end),history.obj(end)]);
af =abs (fmin);
subplot(1,2,1);
semilogy([0,history1.cpu(1:end-1)], [abs(f0-fmin)/af,abs(history1.obj(1:end-1)-fmin)/af],'c--.',...
         [0,history2.cpu(1:end-1)], [abs(f0-fmin)/af,abs(history2.obj(1:end-1)-fmin)/af],'b:.',...
         [0,history3.cpu(1:end-1)], [abs(f0-fmin)/af,abs(history3.obj(1:end-1)-fmin)/af],'k-.',...
         [0,history4.cpu(1:end-1)], [abs(f0-fmin)/af,abs(history4.obj(1:end-1)-fmin)/af],'g-',...
         [0,history5.cpu(1:end-1)], [abs(f0-fmin)/af,abs(history5.obj(1:end-1)-fmin)/af],'m:',...
         [0,history.cpu(1:end-1)], [abs(f0-fmin)/af,abs(history.obj(1:end-1)-fmin)/af],'r--')
ylabel('|F(x^k)-F_{min}|/|F_{min}|'); xlabel('CPU');
legend('IBG-ADMM','NL-ADMM','P-ADMM','BP-ADMM','S-ADMM','I-ADMM')
% title('(m,n)=(500,3000)')
% title('(m,n)=(1000,6000)')
  title('(m,n)=(2000,9000)')
% title('(m,n)=(3000,12000)')

subplot(1,2,2);
semilogy(history1.cpu,history1.opt,'c--.',...
         history2.cpu,history2.opt,'b:.',...
         history3.cpu,history3.opt,'k-.',...
         history4.cpu,history4.opt,'g-',...
         history5.cpu,history5.opt,'m:',...
         history.cpu,history.opt,'r--')
ylabel('Opt(k)'); xlabel('CPU');
legend('IBG-ADMM','NL-ADMM','P-ADMM','BP-ADMM','S-ADMM','I-ADMM')
% title('(m,n)=(500,3000)')
% title('(m,n)=(1000,6000)')
  title('(m,n)=(2000,9000)')
% title('(m,n)=(3000,12000)')