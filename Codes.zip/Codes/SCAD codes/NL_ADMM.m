function [k,x,y,tim,f0,history] = NL_ADMM(A,b,para)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Linearized Alternating Direction Method of Multipliers
% for Constrained Nonconvex Regularized Optimization,JMLR: 
% Workshop and Conference Proceedings 63:97-109, 2016
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%% initial parameters%%%%%%%%%%% 
c     = para.c;
kappa = para.kappa;
Lip   = para.v;
%-----------by the Assumption 3 and Lemma 2 therein --------------------------
%------ but the results are too bad  to satisy the constraints----------------
%  delta = Lip*0.51;  %>Lip/2;
%  beta0 = 1/(2*norm(A)^2*1.01); %< 1/(2*norm(A)^2);
%  beta  = max((3*Lip^2 + 6*delta^2)/(delta-Lip/2), 3/(2*beta0));

%  beta0 = 1/(2*norm(A)^2*1.1); %< 1/(2*norm(A)^2);
%  delta = Lip/2 + beta0;   
%  beta  = (3*Lip^2 + 6*delta^2)/beta0;
%------------------------------------------
beta = 300; %tune

%%%%%%%%%%initial iteration%%%%%%%%%%%%%%
[~, n] = size(A);
y = zeros(n,1);    x = y;   lambda = y;

const_vb = Lip + beta;
const_sbet = 1.6*beta;
f0 = norm(A*x-b)^2/2+ SCA(x,kappa,c);

for k = 1:para.MAX_ITER
    tic;
    
    x_old = x;  y_old = y; 
   %% -----------x-update ---------------------
    x = (para.Ab + beta*y_old + lambda + Lip*x_old - para.ATA*x_old)/const_vb;
    %%
    diff_x = x - x_old;
    
    % -------------y-update---------------------------
    Temp_yk = x- lambda/beta;
    y = scad_prox(Temp_yk,c,1/beta,kappa);
    diff_y = y - y_old;
    
    diff_equ = x - y;
    % -------------lambda-update----------------------
    lambda = lambda - const_sbet*diff_equ;
    
    % ----diagnostics, reporting, termination checks---
    tt = toc;
    if k==1
        history.cpu(k) = tt;
    else
       history.cpu(k) = history.cpu(k-1) + tt; 
    end
    tim = history.cpu(k);
    history.obj(k) =  norm(A*x-b)^2/2 + SCA(x,kappa,c); 
    equ_norm = norm(diff_equ);
    history.RK(k) = norm(diff_x) + norm(diff_y) + equ_norm; 
    history.opt(k) = max( equ_norm, norm(para.ATA*x-para.Ab-lambda) ); % KKT residual

%     fprintf('It:%3d\t Rk:%8.4e\t Fk:%8.4e\t Optk:%8.4e\n',...
%               k,history.RK(k),history.obj(k),history.opt(k));    
    if tim>= para.Time_Budget %history.opt(k)<1e-6   
        break;
     end
%    end

end
fprintf('It_out:%3d\t Fk:%e\t Optk:%8.4e\t Rk:%8.4e\n',...
         k,history.obj(k),history.opt(k), history.RK(k));
fprintf('time: %4.4f\n', tim)
end

 



