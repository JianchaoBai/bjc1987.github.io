function [k,x,y,tim,f0,history] = SADMM(A,b,para)
% % THE CONVERGENCE RATE ANALYSIS OF THE SYMMETRIC
% ADMM FOR THE NONCONVEX SEPARABLE OPTIMIZATION
% PROBLEMS JOURNAL OF INDUSTRIAL AND doi:10.3934/jimo.2020053
% MANAGEMENT OPTIMIZATION
% Volume 17, Number 4, July 2021
%% ======================parameters==================================
[~, n]= size(A); 
kappa = para.kappa;
c     = para.c;

%% =======================================
v = eig(para.ATA);
smalL = abs( min(v) ); 
L = max(  max(v), smalL );

alpha =0.05;
theta =1.2; %>1.2����̫��

t1= 1 - abs((theta-1)/(1+alpha)); %>0
t2= 1/2- alpha*theta/(theta+alpha) - 6*alpha^2*(theta-1)^2/...
     ( abs(1+alpha) - abs(theta-1) )^2*( theta+alpha ); %>0
t3 = 3*L^2*(theta+alpha)/( abs(1+alpha) - abs(theta-1) )^2;
beta =  (L/2 + sqrt(L^2/4 + 4*t2*t3))/(2*t2)+1e-10;

const_ab = alpha*beta;
const_tb = theta*beta;
InvH = inv(para.ATA + beta*eye(n));
%% =======================================
x    = zeros(n,1);  
y    = x;  
lamd = x;
f0   = norm(A*x-b)^2/2 + SCA(x,kappa,c);

%% ===============================================
for k = 1:para.MAX_ITER 
    tic;
    x_old  = x;
    y_old  = y;   
    %===============x-update===================== 
    Temp_xk= y_old + lamd/beta;
    x      = scad_prox(Temp_xk,c,1/beta,kappa);
    diff_x = norm(x - x_old);
    lamd_mid = lamd - const_ab*(x - y_old);
    
    %===============y-update==================  
    y =  InvH*(para.Ab + beta*x - lamd_mid);
    diff_y = y - y_old;   
    %==============dual-update================
    diff_equ = x - y;
    lamd     = lamd_mid - const_tb*diff_equ;
    %=======================================
    tt = toc;
    if k==1
        history.cpu(k) = tt;
    else
       history.cpu(k) = history.cpu(k-1) + tt; 
    end
    tim = history.cpu(k);
    history.obj(k) = norm(A*y-b)^2/2 + SCA(y,kappa,c);
    e1 = norm(diff_equ);
    history.RK(k) = norm(diff_x) + norm(diff_y) + e1;
    e2 = norm(para.ATA*y - para.Ab + lamd);  
    history.opt(k) = max(e1, e2 ); % KKT residual
    if tim>= para.Time_Budget    
    % if history.opt(k) <= 1e-5    
       break;
    end

end
fprintf('It_out:%3d\t Fk:%e\t Optk:%8.4e\t Rk:%8.4e\n',...
         k,history.obj(k),history.opt(k), history.RK(k));
fprintf('time: %4.4f\n', tim)
end

 
