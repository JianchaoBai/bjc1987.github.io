function [k,x,y,tim,f0,history_new] = I_ADMM_New(A,b,para,Rex_par)
%function [k,x_final,y,tim,f0,history] = AI_ADMM_our_mod(G,g,p,para)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%initial iteration%%%%%%%%%%%%%%
[~, n]= size(A);
kappa = para.kappa;
c     = para.c;
%% ------------------------------------------------------------------
% Rex_par = 1.2;
Lip  = para.v;  
%% ======================================================
s = 1;
psi_1  = max( 1, s^2/((2-s)^2) ); 
eta_x = 1/6; eta_y = 1/6;
c_beta= 14;  c_xstop = 1/14; %++++++++++++

% ratio = 20;
% eta_x = 1/ratio; eta_y = 1/ratio;
% c_beta= 2*ratio;  c_xstop = 1/(2*ratio);
%
%% check the following conditions: t1 >0 and t2>0
sigma_A = 1; 
t1 = eta_x/2 - (2*(1/c_beta + c_xstop)^2 + 8*c_xstop^2)*psi_1/(s*sigma_A);%+++++++++++
t2 = eta_y/32 - c_xstop^2*psi_1/(s*sigma_A);  %+++++++++++
delta = 0.1; %+++++++++++
t3 = delta- 8*psi_1/(c_beta^2*s*sigma_A); %+++++++++++
fprintf(" t1: %e t2: %e t3: %e\n",t1,t2,t3);
%pause;
 
x  = zeros(n,1); y = x; lambda = zeros(n,1);
f0 =  norm(A*x-b)^2/2 + SCA(x,kappa,c);
g = para.Ab;
G = para.ATA;
Gx =  G*x;
Gx_hat_old = Gx;
diff_tilde_x_norm = 0; %+++++++++++
L_0 = 1.e0;
L_f = L_0/c_beta ;

for k = 1:  para.MAX_ITER
    tic;
    
    beta = c_beta*L_f;
    c_x = c_xstop*max(1,beta);

    const_etab = 1/((1+eta_y)*beta);
    const_sbet = s*beta;
    const_beta_eta_x = beta*eta_x;
    %---------------------------------------------------------------------
    Gamma = Lip + const_beta_eta_x;  
    Theta = Gamma*(1+1.e-3);    
 %   mu = 0; % Note f is a convex problem
 %   tau   = 1- sqrt(( Theta-mu)/( Theta+mu)); 
    tau = 1 ;
 %  fprintf(" Gamma: %e mu: %e tau: %e \n", Gamma, mu, tau);
    %---------------------------------------------------------------------
    x_old = x;  
    y_old = y; 

    %% --------------- y-update ------------------------
    Temp_yk = const_etab*(beta*(x + eta_y*y_old) - lambda);
    y = scad_prox(Temp_yk,c,const_etab,kappa); 
    diff_y_norm = norm(y - y_old);
     
    %% --------------- x-update ------------------------
    tempt_bxylam =  lambda + beta*(eta_x*x + y)  + g;  %+++++++++++++++
    
    %it = 1 ;
    R_t = diff_y_norm; 
    gradx_norm =  norm(Gx - tempt_bxylam + beta*(1.+eta_x)*x);
    tol_t = max(c_x*R_t,1.e-14) ;
    if gradx_norm <= tol_t 
        diff_equ = x - y ; 
        lambda = lambda - const_sbet*diff_equ;       
    else
        gama_t = 2*Theta;
        q = tempt_bxylam - (Gx+const_beta_eta_x*x) + gama_t*x;
        x_t = q/(gama_t + beta);
        
        for it = 2:1000  
            beta_bar_t = 2/(1+it);
            beta_t   = max(tau, beta_bar_t);
            temp_bxt = (1-beta_t)*x_t; 
            if it > 2 
                x_hat  = beta_t*x_breve + temp_bxt;
            else
                x_hat = x_t ;
            end       
            diff_x = x_hat - x_old;
            diff_x_norm = norm(diff_x);
            R_t  = diff_x_norm + diff_y_norm ; 
            Gx_hat = G*x_hat ;  
            gradx_norm =  norm(Gx_hat - tempt_bxylam + beta*(1.+eta_x)*x_hat);
            tol_t = max(c_x*R_t,1.e-14) ;
            if gradx_norm <= tol_t 
               break;
            end        

            gama_t = beta_t*Theta*(it+1)/it;
            %%------------ x_breve-update--------------------------
            if it > 2 
                q = tempt_bxylam - (Gx_hat+const_beta_eta_x*x_hat) + gama_t*x_breve;
            else
                q = tempt_bxylam - Gx_hat+ (gama_t - const_beta_eta_x)*x_hat; 
            end
            x_breve = q/(gama_t + beta);
            %------------------------------------------------------
            x_t = beta_t*x_breve + temp_bxt;
        end
        
       % tt = norm(Gx_hat - Gx)/diff_x_norm ;    
        tt = norm(Gx_hat-Gx_hat_old)/(diff_x_norm+diff_tilde_x_norm);
        Gx_hat_old = Gx_hat;
        if  tt > L_f
            L_f = min(L_f*1.01, Lip) ;
        end

    %%------------------- lambda-update------------------------------
        diff_equ = x_hat - y ; 
        lambda = lambda - const_sbet*diff_equ;    

    %% ===================extraplolation step==========================
        lambda_diff_x = lambda'*diff_x;
        diff_x_norm2 = diff_x_norm^2;
        G_dx = Gx_hat - Gx;
        rel_g = norm(G_dx)/max(norm(Gx_hat),1);
        ll=0; 
        alpha_k = 1 ;
        phi_k =  x_hat'*(Gx_hat/2 -g) + beta*norm(diff_equ)^2/2;       
        while 1
            alpha_k = Rex_par*alpha_k;
            alpha_e = alpha_k - 1 ;        
            xeta_i = x_hat + alpha_e*diff_x;       
            if rel_g > 1.e-8 
                Gxeta_i = Gx_hat + alpha_e*G_dx ;        
            else
                Gxeta_i = G*xeta_i ;
            end
            tt = xeta_i'*(Gxeta_i/2 -g) ; 
            phi_i =  tt + beta*norm(xeta_i - y)^2/2 ...
                     - alpha_e*lambda_diff_x  + 1.e-1*beta*alpha_e^2*diff_x_norm2;                 
            if (phi_i >= phi_k+ 1.e-16)
                break;
            else
                ll = ll+1 ;
                xeta_old = xeta_i;
                Gxeta_old = Gxeta_i;
            end
        end
        if ( ll > 0 )
            x = xeta_old;
            Gx = Gxeta_old;
            diff_tilde_x_norm = norm(x-x_hat); 
        else
            x = x_hat;   
            Gx = Gx_hat;  
            diff_tilde_x_norm = 0;
        end 
        
    end
    
    %% ------diagnostics, reporting, termination checks---------
    tt = toc;
    if k==1
        history_new.cpu(k) = tt;
    else
       history_new.cpu(k) = history_new.cpu(k-1) + tt; 
    end
    tim = history_new.cpu(k);
    
    bar_x = x_hat ;
    history_new.obj(k) = norm(A*bar_x-b)^2/2 + SCA(bar_x,kappa,c);     
    e1 = norm(bar_x-y);
    history_new.RK(k)  = R_t + e1;
    e2 = norm(G*bar_x -g - lambda) ;
    history_new.opt(k) = max(e1, e2 ); % KKT residual
%     fprintf(' e1: %8.4e e2: %8.4e tol_t: %e gradx_norm: %8.4e ll: %i\n',e1,e2,tol_t,gradx_norm,ll);    
%        fprintf('It_out:%3d\t It_inner:%3d\t Rk:%8.4e\t Fk:%8.4e\t Optk:%8.4e L_f: %e\n',...
%                 k,it,history_new.RK(k),history_new.obj(k),history_new.opt(k), L_f); 
 % pause;
    if tim>= para.Time_Budget %history.opt(k)<1e-6   
       break;
    end

end
fprintf('It_out:%3d\t Fk:%e\t Optk:%8.4e\t Rk:%8.4e\n',...
         k,history_new.obj(k),history_new.opt(k), history_new.RK(k));
fprintf('time: %4.4f\n', tim)
end
 


