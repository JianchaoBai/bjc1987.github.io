function [k,x,y,tim,f0,history] = BPADMM(A,b,para)
% %Radu Ioan Bo?, Dang-Khoa Nguyen (2020) The Proximal Alternating Direction Method of Multipliers in the Nonconvex
% Setting: Convergence Analysis and Rates. Mathematics of Operations Research 45(2):682-712. https://doi.org/10.1287/
% moor.2019.1008 Algorithm 2
%% ======================parameters==================================
[~, n]= size(A); 
kappa = para.kappa;
c     = para.c;

%% =======================================
v = eig(para.ATA);
smalL = abs( min(v) ); 
L = max(  max(v), smalL ); 
s = 1; %(0,2) taking 1 is better than other values
if s>1
    T_0 = s/((2-s)^2);
else 
    T_0 = 1/s;
end
% beta = 6*T_0*L; %>=4
C_M = 6*L^2*T_0;  
beta= 1.2*max(4*T_0*L, (L+sqrt(L^2+4*C_M))/2); %followed by (14)-(15) in the paper
t_k  = beta;  % So M_1^k=0, mu_1=0;

%% =======================================
x    = zeros(n,1);  
y    = x;  
lamd = x;
f0   = norm(A*x-b)^2/2 + SCA(x,kappa,c);

%% ===============================================
for k = 1:para.MAX_ITER 
    tic;
    x_old  = x;
    y_old  = y;   
    %===============y-update===================== 
    Temp_yk= x_old + lamd/beta;
    y      = scad_prox(Temp_yk,c,1/beta,kappa);
    diff_y = norm(y - y_old);
    %===============x-update==================  
    x_tep =  para.ATA*x_old - para.Ab + lamd + beta*(x_old - y);  
    x = x_old - x_tep/t_k;
    diff_x = x - x_old;   
    %==============dual-update================
    diff_equ = x - y;
    lamd     = lamd + s*beta*diff_equ;
    %=======================================
    tt = toc;
    if k==1
        history.cpu(k) = tt;
    else
       history.cpu(k) = history.cpu(k-1) + tt; 
    end
    tim = history.cpu(k);
    history.obj(k) = norm(A*x-b)^2/2 + SCA(x,kappa,c);
    e1 = norm(diff_equ);
    history.RK(k) = norm(diff_x) + norm(diff_y) + e1;
    e2 = norm(para.ATA*x - para.Ab + lamd); %since L=f(x)+g(y) +<lamd, x-y>
    history.opt(k) = max(e1, e2 ); % KKT residual
    if tim>= para.Time_Budget    
    % if history.opt(k) <= 1e-5    
       break;
    end

end
fprintf('It_out:%3d\t Fk:%e\t Optk:%8.4e\t Rk:%8.4e\n',...
         k,history.obj(k),history.opt(k), history.RK(k));
fprintf('time: %4.4f\n', tim)
end

 
