function [k,x,y,tim,f0,history] = PADMM(A,b,para)
% %Li, G., Pong, T.: Global convergence of splitting methods for nonconvex composite optimization.
% SIAM J. Optim. 25(4), 2434�C2460 (2015)
% min f_C(y) + h(x) , s.t. x-y=0
% g(x)=x'*G*x/2- g'*x
% The work assume g is a continuous differentiable function 
%  with its Lipschitz continuous 
%% ======================parameters==================================
[~, n]= size(A); 
kappa = para.kappa;
c     = para.c;
%=======================================
v = eig(para.ATA);
smalL = abs( min(v) ); 
L= max(  max(v), smalL );
beta =  5.1*L;   % By Example 1 therein
%=======================================
x    = zeros(n,1);  
y    = x;  
lamd = x;
f0   = norm(A*x-b)^2/2 + SCA(x,kappa,c);

%% ===============================================
for k = 1:para.MAX_ITER 
    tic;
    x_old  = x;
    y_old  = y;   
    %===============y-update===================== 
    Temp_yk= x_old - lamd/beta;
    y      = scad_prox(Temp_yk,c,1/beta,kappa);
    diff_y = norm(y - y_old);
    %===============x-update==================  
    x = (beta*y + lamd + L*x_old - para.ATA*x_old + para.Ab)/(L+beta);  
    diff_x = x - x_old;   
    %==============dual-update================
    diff_equ = x - y;
    lamd     = lamd - beta*diff_equ;
    %=======================================
    tt = toc;
    if k==1
        history.cpu(k) = tt;
    else
       history.cpu(k) = history.cpu(k-1) + tt; 
    end
    tim = history.cpu(k);
    history.obj(k) = norm(A*x-b)^2/2 + SCA(x,kappa,c);
    e1 = norm(diff_equ);
    history.RK(k) = norm(diff_x) + norm(diff_y) + e1;
    e2 = norm(para.ATA*x - para.Ab - lamd);
    history.opt(k) = max(e1, e2 ); % KKT residual
    if tim>= para.Time_Budget    
    % if history.opt(k) <= 1e-5    
       break;
    end

end
fprintf('It_out:%3d\t Fk:%e\t Optk:%8.4e\t Rk:%8.4e\n',...
         k,history.obj(k),history.opt(k), history.RK(k));
fprintf('time: %4.4f\n', tim)
end

 
