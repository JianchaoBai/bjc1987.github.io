function d = complex_proj(q,v,u)

m = size(v);
for i = 1:m
    if q(i)< v(i)
        d(i)=v(i);
    elseif q(i)> u(i)
        d(i)=u(i);       
    else  
        d(i) = q(i);
    end
end
d=d';