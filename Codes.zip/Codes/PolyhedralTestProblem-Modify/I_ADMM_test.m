function [k,x,y,tim,f0,history_new] = I_ADMM_test(G,g,A,v,u,para)
%function [k,x_final,y,tim,f0,history] = AI_ADMM_our_mod(G,g,p,para)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%initial iteration%%%%%%%%%%%%%%
 [m, n]= size(A); 
%% ------------------------------------------------------------------
Rex_par = 1.2;  %larger?
Lip  = para.L;  
sigma_A = para.sigma_A;
ATA = para.ATA; % AAT = I

e_one = ones(n,1);
c = para.c;
%% ==============parameter setting ================================
s = 1 ;
psi_1  = max( 1, s^2/((2-s)^2) ); 


eta_x = 1/6; eta_y = 1/6;
c_beta= 14;  c_xstop = 1/14;
% 
% ratio = 8e18;
% eta_x = 1/ratio; eta_y = 1/ratio;
% c_beta= 2*ratio;  c_xstop = 1/(2*ratio);
% %
%% check the following conditions: t1 >0 and t2>0
t1 = eta_x/2 - (2*(1/c_beta + c_xstop)^2 + 8*c_xstop^2)*psi_1/(s*sigma_A);
t2 = eta_y/32 - c_xstop^2*psi_1/(s*sigma_A);  
delta = 0.1;
t3 = delta- 8*psi_1/(c_beta^2*s*sigma_A);
fprintf(" t1: %e t2: %e t3: %e\n",t1,t2,t3);
% pause;
 
x  = zeros(n,1);  
y = zeros(m,1); lambda = y;
f0 =  x'*G*x/2 - g'*x;
Gx =  G*x;
Gx_hat_old = Gx;
diff_tilde_x_norm = 0;
Ax =  A*x;
L_0 = 2*para.smalL + 1;
L_f = L_0/c_beta ;

for k = 1:  para.MAX_ITER
    
    tic;    
    beta = c_beta*L_f;
    c_xt = c_xstop*max(1,beta);

    const_etab = 1/((1+eta_y)*beta);
    const_sbet = s*beta;
    const_beta_eta_x = beta*eta_x;
    %---------------------------------------------------------------------
    Gamma = Lip + const_beta_eta_x;
    Theta = Gamma*(1+1.e-3);  %>Gamma  
    mu = max(0, para.smalL - const_beta_eta_x); 
    tau   = 1- sqrt(( Theta-mu)/( Theta+mu));
 %  fprintf(" Gamma: %e mu: %e tau: %e \n", Gamma, mu, tau);
    %---------------------------------------------------------------------
    x_old = x;  
    y_old = y; 

    %% --------------- y-update ------------------------
    Temp_yk = const_etab*( beta*(A*x + eta_y*y_old) - lambda ); 
  % % y = min(max(v, Temp_yk),u);
   % [y, inform] = proj(Temp_yk, e_one, c, v, u);
    [y, inform] = simplex_proj(Temp_yk, e_one, c, v, u, y); %modified
    if inform > 0
        fprintf(" Warning: Projection does not meet accuracy\n");
    end
    diff_y_norm = norm(y - y_old);
     
    %% --------------- x-update ------------------------
    tempt_bxylam_t = A'*(lambda + beta*y)  + g; 
    
    %it = 1 ;
    R_t = diff_y_norm; 
    gradx_norm = norm(Gx - tempt_bxylam_t + beta*ATA*x); 
    tol_t = max(c_xt*R_t,1.e-14) ;
    if gradx_norm <= tol_t 
        diff_equ = A*x - y ; 
        lambda = lambda - const_sbet*diff_equ;       
    else        
        gamma_t = 2*Theta;
        %==================================================================
        b = x + (tempt_bxylam_t -Gx)/gamma_t;
     %   x_t = b - (beta/(beta+gamma_t))*(ATA*b); % ATA = I
        x_t = (gamma_t/(beta+gamma_t))*b;
        
        tempt_bxylam = tempt_bxylam_t  + const_beta_eta_x*x ;       
        for it = 2:1000  
            beta_bar_t = 2/(1+it);
            beta_t   = max(tau, beta_bar_t);
            temp_bxt = (1-beta_t)*x_t; 
            if it > 2 
                x_hat  = beta_t*x_breve + temp_bxt;
            else
                x_hat = x_t ;
            end       
            diff_x = x_hat - x_old;
            diff_x_norm = norm(diff_x);
            R_t  = diff_x_norm + diff_y_norm ; 
            Gx_hat = G*x_hat ;  
            gradx_norm =  norm(Gx_hat - tempt_bxylam + const_beta_eta_x*x_hat + beta*ATA*x_hat);
            tol_t = max(c_xt*R_t,1.e-14) ;
            if gradx_norm <= tol_t
               break;
            end        

            gamma_t = beta_t*Theta*(it+1)/it;
            %%------------ x_breve-update--------------------------
            if it > 2 
                b = x_breve + (tempt_bxylam - (Gx_hat+const_beta_eta_x*x_hat))/gamma_t;
            else
                b = x_hat + (tempt_bxylam - Gx_hat - const_beta_eta_x*x_hat)/gamma_t;
            end
            %% 
          %  x_breve = b - (beta/(beta+gamma_t))*(ATA*b); % ATA = I
            x_breve = (gamma_t/(beta+gamma_t))*b;
            %%
            %------------------------------------------------------
            x_t = beta_t*x_breve + temp_bxt;
        end
        
       % tt = norm(Gx_hat - Gx)/diff_x_norm ; 
        tt = norm(Gx_hat-Gx_hat_old)/(diff_x_norm+diff_tilde_x_norm);
        Gx_hat_old = Gx_hat;        
        if  tt > L_f
            L_f = min(L_f*1.01, Lip) ;
        end

    %%------------------- lambda-update------------------------------
        Ax_hat = A*x_hat;
        diff_equ = Ax_hat - y ; 
        lambda = lambda - const_sbet*diff_equ;    

    %% ===================extraplolation step==========================
        A_dx = Ax_hat - Ax;
        lambda_diff_x = lambda'*A_dx; %modified
        diff_x_norm2 = diff_x_norm^2;
        G_dx = Gx_hat - Gx;
        rel_g = norm(G_dx)/max(norm(Gx_hat),1);
        ll=0; 
        alpha_k = 1 ;
        phi_k =  x_hat'*(Gx_hat/2 -g) + beta*norm(diff_equ)^2/2;       
        while 1
            alpha_k = Rex_par*alpha_k;
            alpha_e = alpha_k - 1 ;        
            xeta_i = x_hat + alpha_e*diff_x;       
            if rel_g > 1.e-8 
                Gxeta_i = Gx_hat + alpha_e*G_dx ;  
                Axeta_i = Ax_hat + alpha_e*A_dx ;
            else
                Gxeta_i = G*xeta_i ;
                Axeta_i = A*xeta_i ;
            end
            tt = xeta_i'*(Gxeta_i/2 -g) ; 
            phi_i =  tt + beta*norm(Axeta_i - y)^2/2 ...
                     - alpha_e*lambda_diff_x  + 1.e-1*beta*alpha_e^2*diff_x_norm2;  %modified      
            if (phi_i >= phi_k - 0.e-16)
                break;
            else
                ll = ll+1 ;
                xeta_old = xeta_i;
                Gxeta_old = Gxeta_i;
                Axeta_old = Axeta_i;
            end
        end
        if ( ll > 0 )
            x = xeta_old;
            Gx = Gxeta_old;  
            diff_tilde_x_norm = norm(x-x_hat);             
            Ax = Axeta_old;
        else
            x = x_hat;   
            Gx = Gx_hat; 
            diff_tilde_x_norm = 0;
            Ax = Ax_hat;
        end 
        
%             ll=0;
%             x = x_hat;   
%             Gx = Gx_hat;  
        
    end
    
    %% ------diagnostics, reporting, termination checks---------
    tt = toc;
    if k==1
        history_new.cpu(k) = tt;
    else
       history_new.cpu(k) = history_new.cpu(k-1) + tt; 
    end
    tim = history_new.cpu(k);
    
    bar_x = x_hat;
    history_new.obj(k) = bar_x'*G*bar_x/2 - g'*bar_x; 
    equ_err = A*bar_x - y;                     %modified
    history_new.RK(k)  = R_t + norm(equ_err,2);%modified   
    e1 = norm(equ_err);                   %modified
    g_x_err = G*bar_x - g - A'*lambda;         %modified
    e2 = norm(g_x_err);                   %modified
    [y_tmp, ~] = proj(y-lambda, e_one, c, v, u);   
    e3 = norm(y - y_tmp);                 %modified
    opt_e = [e1; e2; e3];                      %modified 
    history_new.opt(k) = max(opt_e); % KKT residual %modified
%     fprintf(' e1: %e e2: %e e3: %e tol_t: %e gradx_norm: %e ll: %i\n',e1,e2,e3,tol_t,gradx_norm,ll);    
%        fprintf('It_out:%i\t It_inner:%i\t Rk:%e\t Fk:%e\t Optk:%e L_f: %e\n',...
%                 k,it,history_new.RK(k),history_new.obj(k),history_new.opt(k), L_f); 
%  % pause;
    if tim>= (2*para.Time_Budget)   
       break;
    end

end
fprintf('It_out:%3d\t Fk:%e\t Optk:%8.4e\n',...
         k, min(history_new.obj(k)), min(history_new.opt(k)));
fprintf('time: %4.4f\n', tim)
end
