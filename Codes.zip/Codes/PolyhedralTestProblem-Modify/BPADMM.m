function [k,x,y,tim,f0,history] = BPADMM(G,g,A,v,u,para)
% %Radu Ioan Bo?, Dang-Khoa Nguyen (2020) The Proximal Alternating Direction Method of Multipliers in the Nonconvex
% Setting: Convergence Analysis and Rates. Mathematics of Operations Research 45(2):682-712. https://doi.org/10.1287/
% moor.2019.1008 Algorithm 2
%% ======================parameters==================================
[m, n]= size(A); 
%% =======================================
L = para.L;  
sigma_A= 1; %=1;para.sigma_A


s = 1; %(0,2) taking 1 is better than other values
if s>1
    T_0 = s/(sigma_A*(2-s)^2);
else 
    T_0 = 1/(sigma_A*s);
end
C_M = 6*L^2*T_0; 
xi = max(eig(para.ATA));
beta = 1.2*max(4*T_0*L, (L+sqrt(L^2 + 4*C_M*xi))/(2*xi)); %>=4
t_k  =  beta;  %>=


e_one = ones(n,1);    %modified#####################
c = para.c;           %modified#####################
%% =======================================
x    = zeros(n,1);  
y    = zeros(m,1);  
lamd = y;
f0   = x'*G*x/2 - g'*x;

%% ===============================================
for k = 1:para.MAX_ITER 
    tic;
    %===============y-update===================== 
    Temp_yk= A*x + lamd/beta;
    %     y =  min(max(v, Temp_yk),u);
     % modified#####################
    [y, inform] = proj(Temp_yk, e_one, c, v, u); 
    if inform > 0
        fprintf(" Warning: Projection does not meet accuracy\n");
    end 
    %===============x-update==================  
    x_tep = (G*x - g) + A'*( lamd + beta*(A*x - y) );  
    x = x - x_tep/t_k;
  
    %==============dual-update================
    diff_equ = A*x - y;
    lamd     = lamd + s*beta*diff_equ;
    %=======================================
    tt = toc;
    if k==1
        history.cpu(k) = tt;
    else
       history.cpu(k) = history.cpu(k-1) + tt; 
    end
    tim = history.cpu(k);
    Gx = G*x;
    history.obj(k) = x'*Gx/2 - g'*x;
    %=====================================
    e1 = norm(diff_equ);             %modified ############ 
    e2    = norm(Gx - g + A'*lamd); %modified ############
    [y_tmp, ~] = proj(y+lamd, e_one, c, v, u);  %modified ############ 
    e3 = norm(y - y_tmp);   %modified ############
    opt_e = [e1; e2; e3]; %modified ############     
    %history.opte1(k) = e1; history.opte2(k) = e2;  history.opte3(k) = e3;
    history.opt(k) = max(opt_e); % KKT residual modified ############
    history.xres(k)= norm(x- para.x_opt)/(1+ para.norm_xopt);
    %e_equ = norm(diff_equ);
    %e2    = norm(G*x - g + A'*lamd);
    %history.opt(k) = max(e_equ,e2); % KKT residual
%     fprintf('It_out:%3d\t Fk:%e\t equ:%8.4e\t e2:%8.4e\n',...
%          k, history.obj(k), e_equ, e2);
    if tim>= para.Time_Budget       
       break;
    end

end
fprintf('It_out:%3d\t Fk:%e\t Optk:%8.4e\n',...
          k, history.obj(k), history.opt(k));
fprintf('time: %4.4f\n', tim)
end

 
