%  this function projects x onto the polygon defined
%  by bounds and one linear constraint i.e. 
%     min 1/2 |y - x|^2
%    s.t. BL <= y <= BU
%          r^T y = b
% norm is 2 not Inf
%   Here, y0 is used for adaptive stopping condition
function [y, inform] = simplex_proj(x, r, b, BL, BU, y0)
  inform = 0;
  one = 1.d0;
  zero =0.d0;
  tenth=1.d-1;

 % Set initial eps, lambda, dlambda, gamma    
  eps = 1.d-6; % 1.d-9;
  lambda = zero;
  dlambda = 1.d0;
  gamma = 0.66d0;
  one_eps = one - 1.d-16;
  %=============================
  c_y = 1.e-1; % stop when  res <= max(eps, c_y* norm(y-y0))
  eps_max = c_y;
  %=============================
  % find initial interval [lambda_l, lambda_u] such that
  % res_l = r^t * max(BL, min(BU, x+lambda_l*r )) < 0
  % res_u = r^t * max(BL, min(BU, x+lambda_u*r )) > 0
  % y = max(BL, min(BU, x+lambda*r )) 
  y = x + lambda * r;

  % projection of y on the n-dimensional interval [BL,BU]
  y = mid (y, BL,BU);
  res = r'*y - b;   
  eps_k = min(max(eps, c_y*norm(y-y0)), eps_max);   %=======
  if ( abs(res)<= eps_k )
    return;
  end
  if ( res < zero )
     lambda_l = lambda;
     res_l = res; 
     lambda = lambda + dlambda;
     y = x + lambda * r;
     y = mid (y,BL,BU);
     res = r'*y - b;
     eps_k = min(max(eps, c_y*norm(y-y0)), eps_max); %=======
     if ( abs(res) <= eps_k )
        return;
     end
     while (res < zero )  
        lambda_l = lambda;
        t = min(one ,max(res_l/res-one,tenth));
        dlambda = dlambda / t;
        lambda = lambda + dlambda;
        y = x + lambda*r;
        y = mid (y,BL,BU);
        res_l = res;
        res = r'*y - b;  
         %=============================
        eps_k = min(max(eps, c_y*norm(y-y0)), eps_max); 
        if ( abs(res) <= eps_k )
            return;
        end
     end
     lambda_u = lambda;
     res_u = res;  
   elseif ( res > zero )
     lambda_u = lambda;     
     res_u = res;
     lambda = lambda - dlambda;
     y = x + lambda*r;
     y = mid(y,BL,BU);
     res = r'*y - b; 
     %=============================
     eps_k = min(max(eps, c_y*norm(y-y0)), eps_max); 
     if ( abs(res) <= eps_k )     
        return;  
     end
     while ( res > zero )  
        lambda_u = lambda;
        t = min(one,max(res_u/res-one,tenth));
        dlambda = dlambda/t;  
        lambda = lambda - dlambda;
        y = x + lambda*r;
        y = mid(y,BL,BU);
        res_u = res;
        res = r'*y - b;  
         %=============================
        eps_k = min(max(eps, c_y*norm(y-y0)), eps_max); 
        if ( abs(res) <= eps_k )         
            return;  
        end
     end
     lambda_l = lambda;
     res_l = res; 
  end
  % locate the roots in the interval [lambda_l, lambda_u]
  % using safegarded double secant step
  while (1==1)
    width = gamma*dlambda;
    % first secant step        
    if ( -res_l < res_u )
        lambda = lambda_l - dlambda*(res_l/(res_u-res_l));
    else
        lambda = lambda_u - dlambda*(res_u/(res_u-res_l));
    end
    y = x + lambda*r;        
    y = mid(y,BL,BU);              
    res = r'*y - b; 
     %=============================
    eps_k = min(max(eps, c_y*norm(y-y0)), eps_max); 
    if ( abs(res) <= eps_k )                
        return;    
    end            
    if ( res < zero )
        a0 = lambda_l; 
        res_a0 = res_l;
        lambda_l = lambda;
        res_l = res;
        if (res > (one_eps*res_a0))
            t = lambda - a0;
            lambda = lambda - t*(res/(res-res_a0));  
        end
    else
        b0 = lambda_u;       
        res_b0 = res_u;    
        lambda_u = lambda;
        res_u = res;
        if (res < (one_eps*res_b0)) 
            t = b0 - lambda; 
            lambda = lambda - t*(res/(res_b0-res));
        end 
    end
    if ( ( lambda > lambda_l ) && (lambda < lambda_u ) )
        %2nd secant step is used           
        y = x + lambda*r;         
        y = mid(y,BL,BU);               
        res = r'*y - b;   
        %=============================
        eps_k = min(max(eps, c_y*norm(y-y0)), eps_max); 
        if ( abs(res) <= eps_k )                    
            return;    
        end               
        if (res < zero ) 
            lambda_l = lambda;
            res_l = res;  
        else
            lambda_u = lambda;
            res_u = res;
        end
    end      
    % Bisection secant step
    dlambda = lambda_u - lambda_l;
   % The following line is wrong, in Rohallah original version 
   %    if (dlambda <= width );
    if (dlambda >= width )
        lambda = 0.5*(lambda_l+lambda_u);          
        y = x + lambda*r;         
        y = mid(y,BL,BU);               
        res = r'*y - b;  
         %=============================
        eps_k = min(max(eps, c_y*norm(y-y0)), eps_max); 
        if ( abs(res) <= eps_k )                   
            return;    
        end                
        if (res < zero )  
            lambda_l = lambda;
            res_l = res; 
        else
            lambda_u = lambda;
            res_u = res;
        end
    end
    dlambda = lambda_u - lambda_l ;
    if ( dlambda <= 1.e-10 )
        disp('Proj stopping condition is: ');    
        disp('Interval sufficiently small');
        return;
    end
    if ( dlambda <= (1.e-16 * abs ( lambda_u )))  
        disp('Can not locate lambda, error!');      
        disp('Computer loose accuracy !'); 
        inform = 6;
    end
  end
%computes the projection of x on the n-dimensional interval [xl,xu]
%
function [xnew] = mid (x, xl, xu)
  xnew = max(xl, min(x, xu));
  
