function [k,x,y,tim,f0,history] = SADMM(G,g,A,v,u,para)
% % THE CONVERGENCE RATE ANALYSIS OF THE SYMMETRIC
% ADMM FOR THE NONCONVEX SEPARABLE OPTIMIZATION
% PROBLEMS JOURNAL OF INDUSTRIAL AND doi:10.3934/jimo.2020053
% MANAGEMENT OPTIMIZATION
% Volume 17, Number 4, July 2021
%% ======================parameters==================================
[m, n]= size(A); 
L = para.L;
%% =======================================
alpha =0.05;
theta =1.2; %>1.2����̫��

t1= 1 - abs((theta-1)/(1+alpha)); %>0
t2= 1/2- alpha*theta/(theta+alpha) - 6*alpha^2*(theta-1)^2/...
     ( abs(1+alpha) - abs(theta-1) )^2*( theta+alpha ); %>0
t3 = 3*L^2*(theta+alpha)/( abs(1+alpha) - abs(theta-1) )^2;
beta =  (L/2 + sqrt(L^2/4 + 4*t2*t3))/(2*t2)+1e-10;

const_ab = alpha*beta;
const_tb = theta*beta;
InvGb = inv(G+ beta*speye(n));
%% =======================================

e_one = ones(n,1);    %modified#####################
c = para.c;           %modified#####################

x    = zeros(n,1);  
y    = zeros(m,1);  
lamd = zeros(m,1);
f0   = x'*G*x/2 - g'*x;

%% ===============================================
for k = 1:para.MAX_ITER 
    tic;
    %===============y-update===================== 
    Ax = A*x;
    Temp_yk= Ax - lamd/beta; 
   % y = min(max(v, Temp_yk),u);
    % modified#####################
    [y, inform] = proj(Temp_yk, e_one, c, v, u); 
    if inform > 0
        fprintf(" Warning: Projection does not meet accuracy\n");
    end
    
    lamd_mid = lamd - const_ab*(Ax - y);
    
    %===============y-update==================  
    x =  InvGb*( g + A'*(lamd_mid+beta*y) );   
    %==============dual-update================
    diff_equ = A*x - y;
    lamd     = lamd_mid - const_tb*diff_equ;
    %=======================================
    tt = toc;
    if k==1
        history.cpu(k) = tt;
    else
       history.cpu(k) = history.cpu(k-1) + tt; 
    end
    tim = history.cpu(k);
    Gx = G*x;
    history.obj(k) = x'*Gx/2 - g'*x;
    %======================================
    e1 = norm(diff_equ);             %modified ############ 
    e2    = norm(Gx - g - A'*lamd); %modified ############
    [y_tmp, ~] = proj(y-lamd, e_one, c, v, u);  %modified ############ 
    e3 = norm(y - y_tmp);   %modified ############
    opt_e = [e1; e2; e3]; %modified ############ 
    history.opt(k) = max(opt_e); % KKT residual modified%modified ############
    history.xres(k)= norm(x- para.x_opt)/(1+ para.norm_xopt);
    %======================================
%     e_equ = norm(diff_equ);
%   %  history.RK(k) = norm(diff_x) + norm(diff_y) + e_equ;
%     e2 = norm(G*x - g - A'*lamd);    
%     history.opt(k) = max(e_equ, e2 ); % KKT residual
    if tim>= para.Time_Budget     
       break;
    end
end
fprintf('It_out:%3d\t Fk:%e\t Optk:%8.4e\n',...
         k, history.obj(k), history.opt(k));
fprintf('time: %4.4f\n', tim)
end

 
