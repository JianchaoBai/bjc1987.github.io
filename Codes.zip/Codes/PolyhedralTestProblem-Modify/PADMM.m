function [k,y_final,y,tim,f0,history] = PADMM(G,g,A,v,u,para)
% min f_C(y) + h(x) , s.t. Ax-y=0
% h(x)=x'*G*x/2- g'*x
%% ======================parameters==================================
[m, n]= size(A);  
beta =  5.1*para.L;   % By Example 1 therein
%const_bL = beta/para.L;
e_one = ones(n,1);    %modified#####################
c = para.c;           %modified#####################
x    = zeros(n,1);  
y    = zeros(m,1);  
lamd = zeros(m,1);
f0   = x'*G*x/2 - g'*x;
%% ===============================================
for k = 1:para.MAX_ITER 
    tic;  
    %===============y-update===================== 
    Temp_yk= A*x - lamd/beta; %  %
%      y      = complex_proj(Temp_yk,v,u);
   % modified#####################
    [y, inform] = proj(Temp_yk, e_one, c, v, u); 
    if inform > 0
        fprintf(" Warning: Projection does not meet accuracy\n");
    end
    %===============x-update==================
    b_tep =  (A'*(beta*y + lamd) + g - G*x + para.L*x)/beta; % modified
  %  x = const_bL*b_tep - const_bL^2*A'*( (para.eye + const_bL*para.AAT)\(A*b_tep) );  
  %  x = (t*speye(n) + para.ATA)\b_tep;
     x = (beta/(para.L+beta))*b_tep ;
    %==============dual-update================
    diff_equ = A*x - y; 
    %   %
    lamd     = lamd - beta*diff_equ;
    %=======================================
    tt = toc;
    if k==1
        history.cpu(k) = tt;
    else
       history.cpu(k) = history.cpu(k-1) + tt; 
    end
    tim = history.cpu(k);
    Gx = G*x;
    history.obj(k) = x'*Gx/2 - g'*x; 
    %======================================
    e1 = norm(diff_equ);             %modified ############ 
    e2    = norm(Gx - g - A'*lamd); %modified ############
    [y_tmp, ~] = proj(y-lamd, e_one, c, v, u);   
    e3 = norm(y - y_tmp);   %modified ############
    opt_e = [e1; e2; e3]; %modified ############
    history.opt(k) = max(opt_e); % KKT residual modified%modified ############
    history.xres(k)= norm(x- para.x_opt)/(1+ para.norm_xopt);
    %======================================
%     fprintf('It_out:%3d\t Fk:%e\t opt: %8.4e\t equ:%8.4e\t e2:%8.4e e3: %8.4e\n',...
%          k, history.obj(k),history.opt(k), e_equ, e2, e3);
    if tim>= para.Time_Budget    
       break;
    end

end
fprintf('It_out:%3d\t Fk:%e\t Optk:%8.4e\n',...
         k, min(history.obj(k)), min(history.opt(k)));
fprintf('time: %4.4f\n', tim)
y_final = y;
end


