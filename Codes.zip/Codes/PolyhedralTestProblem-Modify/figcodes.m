 fmin = min([history1.obj(end),history2.obj(end),history3.obj(end),history.obj(end)]);
 af =abs (fmin);
 history.cpu(end)= para.Time_Budget;
 history1.cpu(end)= para.Time_Budget;
 history2.cpu(end)= para.Time_Budget;
 history3.cpu(end)= para.Time_Budget;
 
 set(groot,'defaultLineLineWidth',1.2);
 subplot(1,2,1);
 semilogy([0,history1.cpu(1:end-1)],[abs(f0-fmin),abs(history1.obj(1:end-1)-fmin)]/af,'k-.',...
      [0,history2.cpu(1:end-1)],[abs(f0-fmin),abs(history2.obj(1:end-1)-fmin)]/af,'g-',...
      [0,history3.cpu(1:end-1)],[abs(f0-fmin),abs(history3.obj(1:end-1)-fmin)]/af,'b:',...  
      [0,history.cpu(1:end-1)],[abs(f0-fmin),abs(history.obj(1:end-1)-fmin)]/af,'r--')
 ylabel('|F(x^k)-F_{min}|/|F_{min}|'); xlabel('CPU');
 legend('P-ADMM','BP-ADMM','S-ADMM','I-ADMM')
%  title('n=4000')
%  title('n=5000')
%  title('n=6000')
  title('n=8000') 
%  title('n=10000') 
% title('n=20000')  
 subplot(1,2,2);
 semilogy(history1.cpu, history1.opt,'k-.',...
          history2.cpu, history2.opt,'g-',...
          history3.cpu, history3.opt,'b:',...
          history.cpu, history.opt,'r--')
 ylabel('Opt(k)'); xlabel('CPU');
legend('P-ADMM','BP-ADMM','S-ADMM','I-ADMM')
%  title('n=4000')
%  title('n=5000')
%  title('n=6000')
  title('n=8000') 
%  title('n=10000') 
% title('n=20000')  
 