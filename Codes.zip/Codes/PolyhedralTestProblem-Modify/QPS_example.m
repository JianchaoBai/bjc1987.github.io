%%%%%%%%%%%%%%%%%%%%%% tests %%%%%%%%%%%%%%%%%%%%%%%%
% set up problem: 
% 1/2x'Gx - g'x + indicator(y)
% s.t. Ax - y = 0
% indicator(y): v <= y <= u, e'y = c
%%%%%%%%%%%%%%%%%% generate problem data %%%%%%%%%%%%%%%%%%%%%%%
   n = 2000;  para.Time_Budget=200;
%  n = 3000; para.Time_Budget=300;
%  n = 4000; para.Time_Budget=400;  
% n = 5000; para.Time_Budget=600;
 
fprintf("Problem dimension: %i\t ",n,para.Time_Budget);
randn('seed',0)
D = randn(n);
Z = zeros(n,n);
for i=1:n
    Z(i,i) = 10*(rand(1)-0.1);% i-n/10; %; % i-n/10 ��ĸԽ�󣬸�����ֵԽ��
end
G = D'*Z*D;
g = randn(n,1);
%=============================================
kind =1;
%% convergence of an algorithm is sensetive to data A, u and v
m =n ;
U = randn(n,m);
A = orth(U)';% A = eye(n);
fprintf(" norm(AA'-I): %e \n",norm(A*A' - eye(m)));
if m == n
    para.ATA = speye(n);
else
    para.ATA = A'*A;    
end
para.ATA = speye(n);
para.AAT = speye(n);

u =  10*ones(n,1); 
v =  zeros(n,1);
t1 = sum(v)/n; t2 = sum(u)/n;
c = t1 + (t2-t1)/2; % c=5;% c = t1 + (t2-t1)*rand(1,1);
para.c = c;
fprintf(" c: %e \n",c);
%% ============================================    
%

eig_AAT = eig(para.AAT); 
para.sigma_A = min(eig_AAT(eig_AAT>0)); 
para.eye= speye(m);
para.MAX_ITER=10e8;
eig_G = eig(G);
para.l= abs(max(max(eig_G),0));
para.smalL = abs( min(min(eig_G),0) );
para.L = max( para.l, para.smalL );
condG = cond(G);
fprintf(" max_eig: %e min_eig: %e, condG: %e ||g||: %e sigma_A: %e\n",...
          max(eig_G),min(eig_G), condG, norm(g),para.sigma_A);
% pause
 [~,x_opt,~,~,~,~] = I_ADMM_test(G,g,A,v,u,para);
 para.x_opt= x_opt; 
 para.norm_xopt = norm(x_opt);
 
%%  experiments  
 [k1,x1,~,~,f0,history1]= PADMM(G,g,A,v,u,para); 
 [k2,x2,~,~,~,history2] = BPADMM(G,g,A,v,u,para);
 [k3,x3,~,~,~,history3] = SADMM(G,g,A,v,u,para); 
 [k,x,~,~,~,history] = I_ADMM_New(G,g,A,v,u,para);
 
 %%
 fmin = min([history1.obj(end),history2.obj(end),history3.obj(end),history.obj(end)]);
 af =abs (fmin);
 set(groot,'defaultLineLineWidth',1.2);
 subplot(1,3,1);
  semilogy([0,history1.cpu(1:end-1)],[abs(f0-fmin),abs(history1.obj(1:end-1)-fmin)]/af,'k-.',...
           [0,history2.cpu(1:end-1)],[abs(f0-fmin),abs(history2.obj(1:end-1)-fmin)]/af,'g-',...
           [0,history3.cpu(1:end-1)],[abs(f0-fmin),abs(history3.obj(1:end-1)-fmin)]/af,'b:',...  
           [0,history.cpu(1:end-1)], [abs(f0-fmin),abs(history.obj(1:end-1)-fmin)]/af,'r--')
 ylabel('|F(x^k)-F_{min}|/|F_{min}|'); xlabel('CPU');
 legend('P-ADMM','BP-ADMM','S-ADMM','I-ADMM')
 title('n=2000')
 
 subplot(1,3,2);
 semilogy(history1.cpu, history1.opt,'k-.',...
          history2.cpu, history2.opt,'g-',...
          history3.cpu, history3.opt,'b:',...
          history.cpu, history.opt,'r--')
 ylabel('Opt(k)'); xlabel('CPU');
 legend('P-ADMM','BP-ADMM','S-ADMM','I-ADMM')
 title('n=2000')
 
 subplot(1,3,3);
 semilogy(history1.cpu, history1.xres,'k-.',...
          history2.cpu, history2.xres,'g-',...
          history3.cpu, history3.xres,'b:',...
          history.cpu, history.xres,'r--')
 ylabel('x\_gap(k)'); xlabel('CPU');
 legend('P-ADMM','BP-ADMM','S-ADMM','I-ADMM')
 title('n=2000')